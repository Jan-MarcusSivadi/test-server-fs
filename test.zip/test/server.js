const { urlencoded } = require('express')
const express = require('express')
require('dotenv').config()
const port = process.env.PORT
const environment = process.env.NODE_ENV

const app = express()

// required to get req.body
app.use(express.json())
app.use(urlencoded({ extended: false }))

app.get('/', (req, res) => {
    res.sendFile(__dirname + "/index.html")
})
app.use('/api', require('./routes/mainRoutes'))

app.listen(port, () => console.log(`Server running on port ${port}`))