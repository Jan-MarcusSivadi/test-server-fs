// @desc Create new user
// @route POST /api/users 
const createUser = (req, res) => {
    const { fs, users } = require('../getData')
    console.log(users)
    console.log(fs)

    if (!req.body) {
        res.status(400)
        throw new Error('Request must have at least 1 element in req.body')
    }

    const { id, name, email, password } = req.body

    if (!id || !name || !email || !password) {
        res.status(400)
        throw new Error('Please fill all required fields')
    }
    // console.log(`{ id: ${id}, name: ${name}, email: ${email}, password: ${password} }`)

    // const id = req.body.id
    // const name = req.body.name
    // const email = req.body.email
    // const password = req.body.password

    // if (!id) {
    //     res.status(400)
    //     throw new Error('Please add an id')
    // } else if (!name) {
    //     res.status(400)
    //     throw new Error('Please add a name')
    // } else if (!email) {
    //     res.status(400)
    //     throw new Error('Please add an email')
    // } else if (!password) {
    //     res.status(400)
    //     throw new Error('Please add a password')
    // } 

    // filter by idarr
    var arr = []
    users.forEach(user => {
        arr += user.id
    });
    // console.log('arr: ' + arr)

    if (2 + 2 == 4) {
        // create new user
        let newData = {
            "country": "England"
        }
        // const newUser = {
        //     "id": id,
        //     "name": name,
        //     "email": email,
        //     "password": password,
        // }
        users.push(newData)

        fs.writeFile(users, newData, err => {
            // error checking
            if(err) throw err;
            
            console.log(newUser);
        });   
    }

    res.status(200).json({ users })
}

module.exports = { createUser, }