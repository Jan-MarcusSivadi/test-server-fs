const fs = require('fs');
var data = fs.readFileSync('db/users.json');
var users = JSON.parse(data);

module.exports = { fs, users }