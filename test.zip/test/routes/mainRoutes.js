const express = require('express')
const router = express.Router()
const users = require('../db/users.json')

const { createUser } = require('../controllers/mainController')

router.get('/', (req, res) => {
    res.status(200).json({ message: 'status 200 OK.' })
})

router.get('/users', (req, res) => {
    res.status(200).json({ users })
})

router.post('/users', createUser)

module.exports = router